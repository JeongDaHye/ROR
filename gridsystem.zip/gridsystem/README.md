# KNU_LIKELION 6th 2주차

## 목차

### CSS 배워보기
 
### 부트스트랩 그리드시스템
1. 사이트 접속
* https://getbootstrap.com/ (영어사이트)
* http://bootstrapk.com/ (한국어사이트)
2. 페이지 레이아웃을 만들 때 사용
* 한 행은 반드시 .container 안에 있어야 한다.
* 화면을 8 : 4로 나눠보기
    + col-md-8 col-md-4 
* 화면 위 여백 지정해주기
    + margin-top:_____px

### jQuery API 맛보기
1. 사이트 접속
* http://jquery.com/
2. jQuery API
* 버튼 누르면 사라지게 만들어보기
    + fadeOut()
* 버튼 누르면 생성되게 만들어보기
    + fadeIn()

### Github 계정 생성 & push해보기
    
    