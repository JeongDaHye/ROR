require 'pry'
require 'forecast_io'
require 'geocoder'

ForecastIO.configure do |configuration|
  configuration.api_key = '8d5566e6d7bcf445cbdd9a0422cac499'
end
  
#location의 위도 경도가 배열로 return
def geocode (location)
    Geocoder.coordinates location
end

#섭씨 화씨 변환기
def temp_convert(temp,to)
    temp = temp.to_f
    if to == 'c'
        ((temp - 32) * 5 / 9).round 2
    elsif to == 'f'
        ((temp * 9 / 5) + 32).round 2
    else
        raise ArgumentError, "Argument must be 'f' or 'c'. #{to} is not appropriate."
    end
end

location = '서울'

# f에는 해당 위도 경도의 날씨정보 종합 저장
f = ForecastIO.forecast(geocode(location).first, geocode(location).last)

# c에는 f의 정보 중 현재의 정보만 저장
c = f.currently

puts "#{location}의 날씨: 현재 상태는 #{c.summary}입니다. 온도는 #{temp_convert(c.apparentTemperature, 'x')} ℃입니다."

