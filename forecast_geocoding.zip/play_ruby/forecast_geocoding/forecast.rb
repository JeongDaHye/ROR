require 'pry'
require 'forecast_io'

ForecastIO.configure do |configuration|
  configuration.api_key = '8d5566e6d7bcf445cbdd9a0422cac499'
end

forecast = ForecastIO.forecast(37.566300, 126.977890)
c = forecast.currently
puts "#{forecast.timezone}의 날씨는 #{c.summary} & #{c.apparentTemperature}F"