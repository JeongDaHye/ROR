class LunchController < ApplicationController
  def potato
      @food_list = ["jajangmyeon", "champon", "hamburger", "ramen",
      "chicken", "bibimbap"]
      @food_select = @food_list.sample
      @image_file_name = @food_select + ".jpg"
  end
end
