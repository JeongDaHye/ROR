# KNU_LIKELION 6th 1주차

## 목차

### HTML 배워보기

### 부트스트랩 템플릿으로 자기소개 페이지 만들기
1. 사이트 
* https://startbootstrap.com/ (무료템플릿)
* https://wrapbootstrap.com/ (유료템플릿)
2. 템플릿을 활용하여 자기소개 페이지 만들기
* 창의적으로 나만의 페이지를 만들어 봅시다:)



