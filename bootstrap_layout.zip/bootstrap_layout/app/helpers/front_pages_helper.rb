module FrontPagesHelper
end
